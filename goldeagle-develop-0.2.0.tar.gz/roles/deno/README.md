# Ansible Role: Deno

Installs Deno (https://www.deno.land/) support on Linux.

## Requirements

None.

## Role Variables

NONE

## Dependencies

NONE

## Example Playbook

    - hosts: all
      roles:
        - { role: goldeagle.develop.deno }

## License

Apache-2.0

## Author Information

Bison 'goldeagle' Fan
