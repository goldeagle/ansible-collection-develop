# Ansible Role: Tig

Installs tig (https://github.com/jonas/tig) support on Linux.

## Requirements

None.

## Role Variables

NONE

## Dependencies

NONE

## Example Playbook

    - hosts: all
      roles:
        - { role: goldeagle.develop.tig }

## License

Apache-2.0

## Author Information

Bison 'goldeagle' Fan 
