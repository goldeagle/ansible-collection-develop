# Ansible Role: Chromium

Installs Chromium browser on Linux.

## Requirements

None.

## Role Variables

NONE

## Dependencies

NONE

## Example Playbook

    - hosts: all
      roles:
        - { role: goldeagle.develop.chromium }

## License

Apache-2.0

## Author Information

Bison 'goldeagle' Fan
