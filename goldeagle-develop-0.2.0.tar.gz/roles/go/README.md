# Ansible Role: Go

Installs Go (https://www.rust-lang.org/) support on Linux.

## Requirements

None.

## Role Variables

NONE

## Dependencies

NONE

## Example Playbook

    - hosts: all
      roles:
        - { role: goldeagle.develop.go }

## License

Apache-2.0

## Author Information

Bison 'goldeagle' Fan
