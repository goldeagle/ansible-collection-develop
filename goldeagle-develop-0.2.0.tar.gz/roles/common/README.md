# Ansible Role: Tig

[![Build Status](https://travis-ci.org/geerlingguy/ansible-role-php-mysql.svg?branch=master)](https://travis-ci.org/geerlingguy/ansible-role-php-mysql)

Installs tig (https://www.mysql.com/) support on Linux.

## Requirements

None.

## Role Variables

NONE

## Dependencies

NONE

## Example Playbook

    - hosts: all
      roles:
        - { role: goldeagle.tig }

## License

Apache-2.0

## Author Information

Bison 'goldeagle' Fan
